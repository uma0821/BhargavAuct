import React from 'react'

const Buyer = () => {
  return (
    <>
        <h1>Buyer</h1>
    </>
  )
}

export default Buyer